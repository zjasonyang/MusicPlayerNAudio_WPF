﻿using NaudioPlayer;
using NaudioPlayer.Models;
using System.Collections.Generic;
using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Linq;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;

public class WeeklyScheduleWindowViewModel : ObservableObject
{
    private static bool hasInitializedDefaultSchedule = false;

    //提示 排程已儲存
    public event EventHandler<string> SaveStatusChanged;
    private string _saveStatusMessage;
    public string SaveStatusMessage
    {
        get { return _saveStatusMessage; }
        set
        {
            _saveStatusMessage = value;
            OnPropertyChanged();
        }
    }
    private bool _isPopupOpen;
    public bool IsPopupOpen
    {
        get { return _isPopupOpen; }
        set
        {
            _isPopupOpen = value;
            OnPropertyChanged();
        }
    }

    private ObservableCollection<WeeklySchedule> _weeklySchedules;
    private WeeklySchedule _selectedWeeklySchedule;

    public ObservableCollection<WeeklySchedule> WeeklySchedules
    {
        get { return _weeklySchedules; }
        set
        {
            _weeklySchedules = value;
            OnPropertyChanged();
        }
    }
    public WeeklySchedule SelectedWeeklySchedule
    {
        get { return _selectedWeeklySchedule; }
        set
        {
            _selectedWeeklySchedule = value;
            OnPropertyChanged();
            Console.WriteLine($"SelectedWeeklySchedule: {SelectedWeeklySchedule}");
        }
    }

    public ObservableCollection<string> AvailablePlaylists { get; set; }
    public ObservableCollection<string> AvailableTimes { get; set; }


    public ICommand AddScheduleCommand { get; set; }
    public ICommand SaveScheduleCommand { get; set; }
    public ICommand DeleteScheduleCommand { get; set; }

    public ICommand SaveScheduleToJsonCommand { get; set; }

    public ObservableCollection<SelectableDay> SelectedDaysOfWeek
    {
        get
        {
            return new ObservableCollection<SelectableDay>(SelectedWeeklySchedule.DaysOfWeek.Select(d => new SelectableDay { Day = d, IsSelected = true }));
        }
        set
        {
            SelectedWeeklySchedule.DaysOfWeek = value.Where(x => x.IsSelected).Select(x => x.Day).ToList();
            OnPropertyChanged(nameof(SelectedDaysOfWeek));
        }
    }

    public WeeklyScheduleWindowViewModel()
    {
        LoadCommands();
        // Initialize the WeeklySchedules collection with some sample data

        WeeklySchedules = LoadScheduleFromJson();

        if (WeeklySchedules != null)
        {
            Debug.WriteLine("WeeklySchedules count: " + WeeklySchedules.Count); // Add this line
        }
        else
        {
            Debug.WriteLine("WeeklySchedules is null"); // Add this line
        }

        if (WeeklySchedules == null || WeeklySchedules.Count == 0)
        {
            

            WeeklySchedule defaultSchedule = new WeeklySchedule
            {
                Name = "Default",
                PlaylistPath = "defaultPath",
                StartTime = TimeSpan.Parse("08:00"),
                EndTime = TimeSpan.Parse("16:00"),
                DaysOfWeek = new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Wednesday }
            };

            WeeklySchedules = new ObservableCollection<WeeklySchedule> { defaultSchedule };
            SaveScheduleToJson(); // Save the default schedule to the JSON file
        }
    }

    private void LoadCommands()
    {
        AddScheduleCommand = new RelayCommand(AddSchedule, CanAddSchedule);
        SaveScheduleCommand = new RelayCommand(SaveSchedule, CanSaveSchedule);
        DeleteScheduleCommand = new RelayCommand(DeleteSchedule, CanDeleteSchedule);

        //SaveScheduleToJsonCommand = new RelayCommand(SaveScheduleToJson, CanSaveScheduleToJson);
        SaveScheduleToJsonCommand = new RelayCommand(p => SaveScheduleToJson(), p => CanSaveScheduleToJson());
    }


    private async void SaveScheduleToJson()
    {
        if (WeeklySchedules != null)
        {
            string json = JsonConvert.SerializeObject(WeeklySchedules, Formatting.Indented);
            File.WriteAllText("weeklySchedules.json", json);
            SaveStatusMessage = "Save successful";
            IsPopupOpen = true;
            await Task.Delay(3000);
            IsPopupOpen = false;
        }
        else
        {
            SaveStatusMessage = "Save failed";
            IsPopupOpen = true;
            await Task.Delay(3000);
            IsPopupOpen = false;
        }
    }



    private bool CanSaveScheduleToJson()
    {
        return true;
    }

    private ObservableCollection<WeeklySchedule> LoadScheduleFromJson()
    {
        if (File.Exists("weeklySchedules.json"))
        {
            string json = File.ReadAllText("weeklySchedules.json");
            return JsonConvert.DeserializeObject<ObservableCollection<WeeklySchedule>>(json);
        }
        return null;
    }


    //private WeeklySchedule LoadScheduleFromJson()
    //{
    //    if (File.Exists("schedule.json"))
    //    {
    //        string json = File.ReadAllText("schedule.json");
    //        return JsonConvert.DeserializeObject<WeeklySchedule>(json);
    //    }
    //    return null;
    //}

    private void AddSchedule(object p)
    {
        // Logic to add a new schedule
    }
    private bool CanAddSchedule(object p)
    {
        return true;
    }

    private void SaveSchedule(object p)
    {
          
    }
    private bool CanSaveSchedule(object p)
    {
        return true;
    }

    private void DeleteSchedule(object p)
    {
        // Logic to delete the selected schedule
        if (SelectedWeeklySchedule != null)
        {
            WeeklySchedules.Remove(SelectedWeeklySchedule);
        }
    }
    private bool CanDeleteSchedule(object p)
    {
        return SelectedWeeklySchedule != null;
    }


}

﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using NaudioPlayer.Models;

namespace NaudioPlayer.Views
{
    public partial class DaysOfWeekControl : UserControl
    {
        //public static readonly DependencyProperty SelectedDaysProperty =
        //    DependencyProperty.Register(nameof(SelectedDays), typeof(ObservableCollection<SelectableDay>), typeof(DaysOfWeekControl), new PropertyMetadata(null));

        //public ObservableCollection<SelectableDay> SelectedDays
        //{
        //    get { return (ObservableCollection<SelectableDay>)GetValue(SelectedDaysProperty); }
        //    set { SetValue(SelectedDaysProperty, value); }
        //}

        //public DaysOfWeekControl()
        //{
        //    InitializeComponent();
        //    DataContext = this;
        //}
    }
}
